/*
 * 	Additional function for wysiwyg.html
 *	Written by ThemePixels	
 *	http://themepixels.com/
 *
 *	Built for Shamcey Metro Admin Template
 *  http://themeforest.net/category/site-templates/admin-templates
 */

jQuery(document).ready(function() {

});
